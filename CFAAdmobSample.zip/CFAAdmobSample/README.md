# Android ClickForce SDK 使用中介服務AdMob Sample Project
This project hosts samples for the [Android ClickForce SDK.](http://cdn.doublemax.net/sdk/Android-AdMob.html)
